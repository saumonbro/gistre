#!/bin/sh

cd  bootloader-host

make clean
make depend
make

cd  bootloader-rpi-fixed
make clean
make depend
make



cd ../bootloader-rpi-loaded
make clean
make depend
make

cp kernel8.img ../bootloader-host/boot.img


cd ../application
make clean
make depend
make

cp kernel8.img ../bootloader-host/el0.img

cd ..
