#include "api_lopht.h"
#include "nodes.h"
#include "syncvars.h"
#include "threads.h"
#include "variables.h"

SECTION_ATTR(".text.cpu1")
void mif_entry_point_cpu1(void) {
  // UPDATE_CPU(loc_pc_1, 1);
  f_step(&x);
  UPDATE_CPU(loc_pc_1, 1);

  //  WAIT_CPU(loc_pc_0, 1);
  m_step(x, &u);
  // UPDATE_CPU(loc_pc_1, 1);

  WAIT_CPU(loc_pc_0, 1);
  n_step(u, z_1);

  UPDATE_CPU(loc_pc_1, 2);
  WAIT_END(loc_pc_0);

  /* Wait until interrupted. */
  for (;;)
    ; // Could use a WFE statement
}
