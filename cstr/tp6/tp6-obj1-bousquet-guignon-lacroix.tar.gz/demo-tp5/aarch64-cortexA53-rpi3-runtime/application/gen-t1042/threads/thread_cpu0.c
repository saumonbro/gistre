#include "api_lopht.h"
#include "nodes.h"
#include "syncvars.h"
#include "threads.h"
#include "variables.h"

SECTION_ATTR(".text.cpu0")
__attribute__((noinline)) void global_init(void) {}

SECTION_ATTR(".text.cpu0")
void mif_entry_point_cpu0(void) {
  //  UPDATE_CPU(loc_pc_0, 0);
  g_step(z_1, &y);

  WAIT_CPU(loc_pc_1, 1);
  h_step(x, y, &z_1);
  UPDATE_CPU(loc_pc_0, 1);

  WAIT_CPU(loc_pc_1, 2);
  loc_pc_1 = -1;
  UPDATE_CPU(loc_pc_0, -1);

  /* Wait until interrupted. */
  for (;;)
    ; // Could use a WFE statement
}
